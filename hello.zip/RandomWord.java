import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;

public class RandomWord {
    public static void main(String[] args) {
        String champion = null; // Holds the currently selected word
        int i = 1; // Word count

        // Read each word from standard input
        while (!StdIn.isEmpty()) {
            String currentWord = StdIn.readString();

            // Select the current word as the champion with probability 1/i
            if (Math.random() < (1.0 / i)) {
                champion = currentWord;
            }

            i++; // Increment word counter
        }

        // Print the surviving champion (the randomly selected word)
        if (champion != null) {
            StdOut.println(champion);
        }
    }
}
